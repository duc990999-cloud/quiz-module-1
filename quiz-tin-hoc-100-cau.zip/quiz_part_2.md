# Phần 2: Câu 26 – Câu 50

### Câu 26: Webpage là gì?
- [ ] A. Là tập hợp của nhiều website
- [ ] B. Là một phần của website
- [ ] C. Là cách gọi khác của website
- [ ] D. Là một trình duyệt web

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Webpage (trang web) là một trang đơn lẻ cấu thành nên một website tổng thể.
</details>

---

### Câu 27: Trong Microsoft PowerPoint 2010, cách làm nào sau đây không phải để trình chiếu bài trình diễn:
- [ ] A. Slide Show \ Custom Show.
- [ ] B. Slide Show \ From Beginning.
- [ ] C. Nhấn tổ hợp phím Shift + F5.
- [ ] D. Nhấn phím F5.

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* **Custom Show** dùng để thiết lập kịch bản chiếu tùy chọn các slide, không phải thao tác phát trình chiếu trực tiếp.
</details>

---

### Câu 28: Trong Microsoft PowerPoint 2010, để đưa thêm nút điều khiển (Action Buttons) vào slide hiện hành, người thiết kế có thể chọn:
- [ ] A. Insert \ Illustrations \ Shapes \ Action Buttons.
- [ ] B. AutoShapes \ Action Buttons.
- [ ] C. Slide Show \ Action Buttons.
- [ ] D. Design \ Action Buttons.

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Các nút điều hướng Action Buttons nằm ở hàng cuối cùng trong menu Shapes tại thẻ Insert.
</details>

---

### Câu 29: Phần mở rộng của Microsoft PowerPoint 2010 là gì?
- [ ] A. docx
- [ ] B. xlsx
- [ ] C. html
- [ ] D. pptx

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* PowerPoint từ phiên bản 2007 trở đi có định dạng tệp mặc định là `.pptx`.
</details>

---

### Câu 30: Trong Microsoft PowerPoint 2010, để thêm một slide vào vị trí bên dưới slide hiện thời, ta thực hiện thao tác nào?
- [ ] A. Ctrl + A
- [ ] B. Ctrl + M
- [ ] C. Ctrl + B
- [ ] D. Alt + M

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* **Ctrl + M** là phím tắt để chèn thêm một slide mới.
</details>

---

### Câu 31: Trong Microsoft Word 2010, khi ta thực hiện thao tác chọn Page Layout \ Page Setup \ Orientation \ Portrait có nghĩa là:
- [ ] A. Chọn hướng giấy ngang
- [ ] B. Chọn hướng giấy dọc
- [ ] C. Điều chỉnh lề cho trang giấy
- [ ] D. Thiết lập khổ giấy (A4, Letter, ...)

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* **Portrait** là thiết lập hướng giấy in đứng/dọc.
</details>

---

### Câu 32: Thiết bị xuất gồm:
- [ ] A. Màn hình, máy in
- [ ] B. Scanner, webcam
- [ ] C. Chuột, bàn phím
- [ ] D. Loa, Micro

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Màn hình và máy in là các thiết bị xuất dữ liệu (Output devices). Micro và Scanner là thiết bị nhập.
</details>

---

### Câu 33: Trong hệ điều hành Windows, muốn đóng nhanh cửa sổ (ứng dụng) đang mở, cần sử dụng tổ hợp phím:
- [ ] A. Alt + Tab
- [ ] B. Alt + Shift
- [ ] C. Alt + Home
- [ ] D. Alt + F4

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* **Alt + F4** dùng để đóng nhanh cửa sổ ứng dụng đang kích hoạt.
</details>

---

### Câu 34: Trong Microsoft Word 2010, để sử dụng Tab trong Table (bảng), ta sử dụng:
- [ ] A. Ctrl + Tab
- [ ] B. Tab
- [ ] C. Shift + Tab
- [ ] D. Alt + Tab

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Nhấn **Ctrl + Tab** để đặt bước nhảy tab bên trong ô của bảng.
</details>

---

### Câu 35: Trong Microsoft Word 2010, cách nhanh nhất để chọn (bôi đen) từ con trỏ về cuối dòng là nhấn tổ hợp phím:
- [ ] A. Alt + F8
- [ ] B. Ctrl + End
- [ ] C. Shift + End
- [ ] D. Alt + A

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* **Shift + End** chọn văn bản từ vị trí con trỏ hiện tại đến cuối dòng.
</details>

---

### Câu 36: Trong Microsoft Word 2010, để chèn một Textbox trong văn bản, ta sử dụng:
- [ ] A. Insert \ Illustrations \ Text Box
- [ ] B. Insert \ Text \ Text Box
- [ ] C. Home \ Font \ Text Box
- [ ] D. Home \ Paragraph \ Text Box

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Chọn thẻ **Insert** -> mục **Text** -> **Text Box**.
</details>

---

### Câu 37: Trong Microsoft Word 2010, khi đang soạn thảo một văn bản chưa lưu, nếu ta chọn tổ hợp phím Ctrl + S thì thao tác nào sau đây sẽ xảy ra (lần lưu đầu tiên):
- [ ] A. Mở hộp thoại "Save As" để đặt tên và chọn nơi lưu
- [ ] B. Đóng văn bản ngay lập tức
- [ ] C. In văn bản ra máy in
- [ ] D. Chuyển văn bản sang chế độ đọc (Read Mode)

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Lưu lần đầu tiên hệ thống sẽ yêu cầu đặt tên file và chọn thư mục lưu thông qua hộp thoại Save As.
</details>

---

### Câu 38: Trong Microsoft Word 2010, muốn xóa tất cả ký tự từ trước con trỏ văn bản lùi về đến khi gặp khoảng trắng đầu tiên (dấu cách) ta nhấn tổ hợp phím:
- [ ] A. Ctrl + Backspace
- [ ] B. Alt + Delete
- [ ] C. Ctrl + Delete
- [ ] D. Alt + D

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* **Ctrl + Backspace** xóa từ trước con trỏ lùi về khoảng trắng gần nhất.
</details>

---

### Câu 39: Trong một văn bản của Microsoft Word 2010, để chọn nhiều hình (hoặc đối tượng) liền kề nhau, ta cần giữ phím nào trong khi chọn?
- [ ] A. Shift
- [ ] B. Ctrl
- [ ] C. Alt
- [ ] D. Tab

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Phím **Shift** (hoặc Ctrl) hỗ trợ chọn nhiều đối tượng nối tiếp/liền kề.
</details>

---

### Câu 40: Trong soạn thảo Microsoft Word 2010, muốn đánh số đầu đoạn văn bản (1, 2, 3, ...), ta chọn:
- [ ] A. Insert \ Symbol
- [ ] B. Home \ Paragraph \ Bullets
- [ ] C. Home \ Symbol
- [ ] D. Home \ Paragraph \ Numbering

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* **Numbering** trong nhóm Paragraph thẻ Home dùng để tạo danh sách đánh số tự động.
</details>

---

### Câu 41: Trong soạn thảo Microsoft Word 2010, để chuyển đổi chữ thường thành chữ in hoa hoặc ngược lại ta sử dụng tổ hợp phím:
- [ ] A. Ctrl + Shift + C
- [ ] B. Shift + A
- [ ] C. Ctrl + Shift + B
- [ ] D. Shift + F3

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* **Shift + F3** cho phép luân chuyển giữa 3 trạng thái: chữ hoa toàn bộ, chữ thường toàn bộ, và viết hoa chữ cái đầu.
</details>

---

### Câu 42: Khi soạn thảo văn bản trong Microsoft Word 2010, nếu muốn xuống dòng mà không muốn kết thúc một đoạn (Paragraph) ta thực hiện:
- [ ] A. Bấm phím Enter
- [ ] B. Bấm tổ hợp phím Shift + Enter
- [ ] C. Bấm tổ hợp phím Ctrl + Enter
- [ ] D. Word tự động không cần bấm phím

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* **Shift + Enter** ngắt dòng mềm (Line Break) mà không tạo đoạn văn bản mới.
</details>

---

### Câu 43: Trong Microsoft Excel 2010, tại ô A2 có giá trị là chuỗi TinHoc; Tại ô C2 gõ vào công thức =UPPER(A2) thì nhận được kết quả tại ô C2:
- [ ] A. #Value
- [ ] B. TINHOC
- [ ] C. TinHoc
- [ ] D. tinhoc

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Hàm `=UPPER()` chuyển toàn bộ chuỗi ký tự sang chữ in hoa.
</details>

---

### Câu 44: Trong Microsoft Excel 2010, giả sử ô A1, A2, A3, có chứa lần lượt các số: 234, "235", 236, tại ô A4 nhập công thức =COUNT(A1:A3) thì kết quả là:
- [ ] A. 3
- [ ] B. 2
- [ ] C. 1
- [ ] D. 0

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Hàm `COUNT()` chỉ đếm các ô chứa giá trị số (ô A1=234 và ô A3=236), bỏ qua chuỗi `"235"`. Do đó kết quả là 2.
</details>

---

### Câu 45: Giá trị trả về của hàm =IF(10>2, "False", "True") trong Microsoft Excel 2010 là:
- [ ] A. True
- [ ] B. False
- [ ] C. 2024
- [ ] D. Đúng

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Vì `10 > 2` là TRUE nên hàm trả về giá trị ở đối số thứ hai là `"False"`.
</details>

---

### Câu 46: Trong Microsoft Excel 2010, hãy xác định địa chỉ nào là địa chỉ tương đối?
- [ ] A. B1:D10
- [ ] B. $B1:$D10
- [ ] C. B$1$:D$10$
- [ ] D. $B$1:$D$10

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Địa chỉ tương đối không có dấu `$` ở cả hàng và cột (`B1:D10`).
</details>

---

### Câu 47: Trong Microsoft Excel, để thay thế (Replace) dữ liệu, ta dùng tổ hợp phím:
- [ ] A. Ctrl + F
- [ ] B. Ctrl + H
- [ ] C. Ctrl + B
- [ ] D. Ctrl + P

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* **Ctrl + H** mở tab Replace trong hộp thoại Find and Replace.
</details>

---

### Câu 48: Trong Microsoft Excel 2010, tổ hợp phím nào được sử dụng để tự động chèn hàm SUM vào ô hiện tại?
- [ ] A. Ctrl + =
- [ ] B. Alt + =
- [ ] C. Tab + =
- [ ] D. Shift + =

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* **Alt + =** là phím tắt của tính năng tự động tính tổng (AutoSum).
</details>

---

### Câu 49: Hàm nào có tác dụng trả về năm hiện hành của hệ thống?
- [ ] A. =NOW()
- [ ] B. =DAY(NOW())
- [ ] C. =YEAR(MONTH())
- [ ] D. =YEAR(NOW())

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* Hàm `=YEAR(NOW())` trích xuất giá trị năm từ thời gian hệ thống hiện tại do hàm `NOW()` cung cấp.
</details>

---

### Câu 50: Trong Microsoft Excel 2010, ký tự nào được dùng để phân cách địa chỉ ô đầu và ô cuối khi viết địa chỉ của một khối dữ liệu?
- [ ] A. Dấu chấm phẩy (;)
- [ ] B. Dấu phẩy (,)
- [ ] C. Dấu gạch ngang (-)
- [ ] D. Dấu hai chấm (:)

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* Dấu hai chấm `:` đại diện cho toán tử tham chiếu vùng (ví dụ: `A1:B10`).
</details>