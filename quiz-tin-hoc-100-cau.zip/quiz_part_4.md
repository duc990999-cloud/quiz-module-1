# Phần 4: Câu 76 – Câu 100

### Câu 76: Trong Microsoft Excel 2010, để hiện lại (Unhide) cột B đang bị ẩn (khi thấy cột C đứng ngay sau cột A), ta thực hiện:
- [ ] A. Chọn cột C, Delete Column
- [ ] B. Chọn cột A, Format Cells
- [ ] C. Chọn cột A và cột C, Home \ Format \ Hide & Unhide \ Unhide Columns
- [ ] D. Data, Sort A to Z

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* Để hiện lại cột bị ẩn giữa 2 cột, bôi đen cả 2 cột kẹp trước và sau (cột A và C), sau đó chọn Unhide Columns.
</details>

---

### Câu 77: Trong Microsoft Excel 2010, hãy xác định địa chỉ nào là địa chỉ tương đối?
- [ ] A. B1:D10
- [ ] B. $B1:$D10
- [ ] C. B$1$:D$10$
- [ ] D. $B$1:$D$10

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* `B1:D10` không chứa ký tự cố định `$` nên là địa chỉ tương đối.
</details>

---

### Câu 78: Trong Microsoft Excel, để thay thế (Replace) dữ liệu, ta dùng tổ hợp phím:
- [ ] A. Ctrl + F
- [ ] B. Ctrl + H
- [ ] C. Ctrl + B
- [ ] D. Ctrl + P

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Phím tắt **Ctrl + H** kích hoạt tính năng Replace trong Excel.
</details>

---

### Câu 79: Hàm nào có tác dụng trả về năm hiện hành của hệ thống?
- [ ] A. =NOW()
- [ ] B. =DAY(NOW())
- [ ] C. =YEAR(MONTH())
- [ ] D. =YEAR(NOW())

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* `=YEAR(NOW())` lấy giá trị năm từ thời gian hệ thống hiện hành.
</details>

---

### Câu 80: Trong Microsoft Excel 2010, ký tự nào được dùng để phân cách địa chỉ ô đầu và ô cuối khi viết địa chỉ của một khối dữ liệu?
- [ ] A. Dấu chấm phẩy (;)
- [ ] B. Dấu phẩy (,)
- [ ] C. Dấu gạch ngang (-)
- [ ] D. Dấu hai chấm (:)

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* Cặp ô giới hạn vùng chọn được nối với nhau qua dấu hai chấm `:`.
</details>

---

### Câu 81: Trong Microsoft Excel 2010, toán tử Logic nào có tác dụng trả về TRUE khi cả hai điều kiện đều đúng?
- [ ] A. Or
- [ ] B. NOT
- [ ] C. AND
- [ ] D. XOR

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* Hàm `AND(đk1, đk2)` trả về TRUE khi tất cả các biểu thức logic đều đúng.
</details>

---

### Câu 82: Trong Microsoft PowerPoint 2010, cách làm nào sau đây không phải để trình chiếu bài trình diễn:
- [ ] A. Home \ New Slide.
- [ ] B. Slide Show \ From Beginning.
- [ ] C. Nhấn tổ hợp phím Shift + F5.
- [ ] D. Nhấn phím F5.

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Lệnh New Slide là thêm slide mới.
</details>

---

### Câu 83: Trong Microsoft PowerPoint 2010, để nhân bản (Duplicate) slide hiện thời, ta dùng tổ hợp phím nào?
- [ ] A. Ctrl + A
- [ ] B. Ctrl + D
- [ ] C. Ctrl + B
- [ ] D. Ctrl + M

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Phím tắt **Ctrl + D** thực hiện lệnh Duplicate (nhân bản) đối tượng hoặc slide đang chọn.
</details>

---

### Câu 84: Trong các địa chỉ sau, địa chỉ nào thuộc dịch vụ Gmail?
- [ ] A. DaihocTanTrao@gmail.com
- [ ] B. DaihocTanTrao@outlook.com
- [ ] C. DaihocTanTrao.gmail@company.vn
- [ ] D. DaihocTanTrao@com.vn.gmail

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Đuôi email `@gmail.com` đại diện cho tài khoản Google Gmail.
</details>

---

### Câu 85: Website là gì?
- [ ] A. Là một trang web đơn lẻ
- [ ] B. Là tập hợp nhiều trang web (webpage) liên quan, được lưu trên máy chủ và truy cập qua Internet
- [ ] C. Là một trình duyệt web
- [ ] D. Là một công cụ tìm kiếm

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Website là tập hợp của nhiều trang web (webpage) có cùng tên miền và liên kết chặt chẽ với nhau.
</details>

---

### Câu 86: Đơn vị đo tốc độ CPU là?
- [ ] A. Megabit (Mbps)
- [ ] B. Kylobyte (KBps)
- [ ] C. Kylobit (Kbps)
- [ ] D. Gigaherts (GHz)

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* Tốc độ xử lý của CPU được đo bằng Gigahertz (GHz).
</details>

---

### Câu 87: Cổng COM là:
- [ ] A. Cổng nối tiếp
- [ ] B. Cổng song song
- [ ] C. Cổng vạn năng
- [ ] D. Cổng mạng

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Cổng COM là cổng giao tiếp truyền thông nối tiếp (Serial Port).
</details>

---

### Câu 88: Theo thứ tự đơn vị dung lượng tăng dần nào sau đây là đúng?
- [ ] A. Byte - Bit - KB - MB
- [ ] B. Bit - Byte - MB - KB
- [ ] C. Bit - Byte - KB - MB
- [ ] D. KB - Byte - Bit - MB

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* Thứ tự tăng dần đúng chuẩn: Bit -> Byte -> KB -> MB.
</details>

---

### Câu 89: Trong Microsoft Word 2010, khi ta thực hiện thao tác chọn Page Layout \ Page Setup \ Orientation \ Landscape có nghĩa là:
- [ ] A. Chọn hướng giấy ngang
- [ ] B. Chọn hướng giấy dọc
- [ ] C. Điều chỉnh lề cho trang giấy
- [ ] D. Cả 3 ý trên đều sai

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Orientation Landscape thiết lập hướng trang nằm ngang.
</details>

---

### Câu 90: Thiết bị nhập gồm:
- [ ] A. Màn hình, máy chiếu
- [ ] B. Máy in, webcam
- [ ] C. Chuột, bàn phím
- [ ] D. Loa, scanner

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* Chuột và bàn phím là các thiết bị nhập thông tin chuẩn.
</details>

---

### Câu 91: Trong hệ điều hành Windows, muốn chuyển đổi nhanh giữa các cửa sổ đang mở, cần sử dụng tổ phím:
- [ ] A. Alt + Tab
- [ ] B. Alt + Shift
- [ ] C. Alt + Home
- [ ] D. Alt + Enter

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* **Alt + Tab** chuyển đổi qua lại giữa các cửa sổ ứng dụng đang chạy.
</details>

---

### Câu 92: Ký tự đại diện (Wildcard) nào sau đây để thay thế cho 1 nhóm ký tự của tên tập tin:
- [ ] A. ~ (dấu ngã)
- [ ] B. * (dấu sao)
- [ ] C. ? (dấu hỏi)
- [ ] D. . (dấu chấm)

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Ký tự `*` đại diện cho một chuỗi bất kỳ ký tự nào, còn `?` chỉ đại diện cho duy nhất 1 ký tự.
</details>

---

### Câu 93: Trong Microsoft Word 2010, để xóa bỏ toàn bộ định dạng kiểu chữ của văn bản đang chọn, ta nhấn tổ hợp phím:
- [ ] A. Ctrl + Space
- [ ] B. Ctrl + Delete
- [ ] C. Ctrl + Enter
- [ ] D. Shift + Space

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* **Ctrl + Space** đưa kiểu chữ về định dạng mặc định ban đầu.
</details>

---

### Câu 94: Trong Microsoft Word 2010, cách nhanh nhất để chọn (bôi đen) từ con trỏ về đầu dòng là nhấn tổ hợp phím:
- [ ] A. Alt + F8
- [ ] B. Ctrl + End
- [ ] C. Shift + Home
- [ ] D. Alt + A

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* **Shift + Home** chọn từ vị trí con trỏ về đầu dòng.
</details>

---

### Câu 95: Trong Microsoft Word 2010, muốn xóa tất cả ký tự từ sau con trỏ văn bản đến khi gặp khoảng trắng đầu tiên (dấu cách), ta nhấn tổ hợp phím:
- [ ] A. Ctrl + D
- [ ] B. Alt + Delete
- [ ] C. Ctrl + Delete
- [ ] D. Alt + D

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* **Ctrl + Delete** xóa từ bên phải con trỏ tới hết từ tiếp theo.
</details>

---

### Câu 96: Trong một văn bản của Microsoft Word 2010, để chọn được nhiều hình không liền kề thì ta phải giữ thêm phím nào trong khi chọn:
- [ ] A. Shift
- [ ] B. Ctrl
- [ ] C. Alt
- [ ] D. Tab

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Phím **Ctrl** dùng để chọn ngẫu nhiên nhiều đối tượng không liền kề nhau.
</details>

---

### Câu 97: Trong soạn thảo Microsoft Word 2010, muốn đánh dấu đầu đoạn văn bản bằng các ký tự đặc biệt, ta chọn:
- [ ] A. Insert \ Symbol
- [ ] B. Home \ Paragraph \ Bullets
- [ ] C. Page \ Symbol
- [ ] D. File \ Paragraph \ Numbering

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Chọn tính năng **Bullets** trong nhóm Paragraph thẻ Home để tạo các gạch đầu dòng ký hiệu đặc biệt.
</details>

---

### Câu 98: Trong soạn thảo Microsoft Word 2010, để chuyển đổi chữ thường thành chữ in hoa hoặc ngược lại ta sử dụng tổ hợp phím:
- [ ] A. Ctrl + Shift + C
- [ ] B. Ctrl + Shift + A
- [ ] C. Ctrl + Shift + B
- [ ] D. Ctrl + Shift + D

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* **Ctrl + Shift + A** bật/tắt toàn bộ chữ in hoa (All Caps).
</details>

---

### Câu 99: Trong Microsoft Excel 2010, tại ô A2 có giá trị là chuỗi Tin Học; Tại ô C2 gõ vào công thức =LOWER(A2) thì nhận được kết quả tại ô C2:
- [ ] A. #Value
- [ ] B. TINHOC
- [ ] C. TinHoc
- [ ] D. tinhoc

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* Hàm `=LOWER()` chuyển toàn bộ chuỗi ký tự thành chữ thường ("tin học").
</details>

---

### Câu 100: Hàm nào có tác dụng trả về ngày hiện hành của hệ thống (không kèm giờ):
- [ ] A. =NOW()
- [ ] B. =DAY(NOW())
- [ ] C. =TODAY()
- [ ] D. =TODAY(NOW())

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* `=TODAY()` trả về ngày hiện hành không kèm giờ phút.
</details>