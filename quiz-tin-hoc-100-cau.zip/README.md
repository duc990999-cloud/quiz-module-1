# Bộ 100 Câu Hỏi Trắc Nghiệm Tin Học Văn Phòng

Bộ đề ôn tập trắc nghiệm Tin học văn phòng (Word, Excel, PowerPoint, Windows, Kiến thức máy tính cơ bản).

## 📂 Danh mục bài ôn tập

- [x] [Bài 1: Câu 01 – Câu 25](./quiz_part_1.md)
- [x] [Bài 2: Câu 26 – Câu 50](./quiz_part_2.md)
- [x] [Bài 3: Câu 51 – Câu 75](./quiz_part_3.md)
- [x] [Bài 4: Câu 76 – Câu 100](./quiz_part_4.md)

## 💡 Hướng dẫn làm Quiz trên GitHub
- Mỗi câu hỏi được định dạng dạng checklist `- [ ]`.
- Bạn có thể tick chọn đáp án trực tiếp khi xem file markdown trên GitHub.
- Bấm vào mục **👉 Xem đáp án** bên dưới mỗi câu để kiểm tra kết quả và xem giải thích chi tiết.