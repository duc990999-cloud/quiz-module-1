# Phần 1: Câu 01 – Câu 25

### Câu 1: Bộ nhớ truy cập ngẫu nhiên RAM được viết tắt là:
- [ ] A. Read Access Memory
- [ ] B. Rewrite Access Memory
- [ ] C. Random Access Memory
- [ ] D. Secondary Memory

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* RAM là viết tắt của **Random Access Memory** (Bộ nhớ truy cập ngẫu nhiên).
</details>

---

### Câu 2: Trong Microsoft Word 2010, khi ta thực hiện thao tác chọn Page Layout \ Page Setup \ Orientation \ Landscape có nghĩa là:
- [ ] A. Chọn hướng giấy ngang
- [ ] B. Chọn hướng giấy dọc
- [ ] C. Điều chỉnh lề cho trang giấy
- [ ] D. Cả 3 ý trên đều sai

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Trong thẻ Page Setup, **Landscape** là hướng giấy ngang, còn **Portrait** là hướng giấy dọc.
</details>

---

### Câu 3: Thiết bị nhập gồm:
- [ ] A. Màn hình, máy chiếu
- [ ] B. Máy in, webcam
- [ ] C. Chuột, bàn phím
- [ ] D. Loa, scanner

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* Chuột và bàn phím là các thiết bị nhập (Input devices) dữ liệu chuẩn vào máy tính.
</details>

---

### Câu 4: Trong hệ điều hành Windows, muốn chuyển đổi nhanh giữa các cửa sổ đang mở, cần sử dụng tổ phím:
- [ ] A. Alt + Tab
- [ ] B. Alt + Shift
- [ ] C. Alt + Home
- [ ] D. Alt + Enter

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Tổ hợp phím **Alt + Tab** dùng để chuyển đổi nhanh qua lại giữa các cửa sổ ứng dụng đang mở.
</details>

---

### Câu 5: Trong Microsoft Word 2010, để xóa bỏ toàn bộ định dạng kiểu chữ của văn bản đang chọn, ta nhấn tổ hợp phím:
- [ ] A. Ctrl + Space
- [ ] B. Ctrl + Delete
- [ ] C. Ctrl + Enter
- [ ] D. Shift + Space

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Phím tắt **Ctrl + Space** (hoặc nút Clear All Formatting) giúp đưa kiểu chữ đã chọn về định dạng mặc định (Normal).
</details>

---

### Câu 6: Trong Microsoft Word 2010, để sử dụng Tab trong Table (bảng), ta sử dụng:
- [ ] A. Ctrl + Tab
- [ ] B. Tab
- [ ] C. Shift + Tab
- [ ] D. Alt + Tab

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Trong bảng (Table), phím **Tab** dùng để nhảy giữa các ô; muốn thụt lề bằng ký tự Tab trong ô phải nhấn **Ctrl + Tab**.
</details>

---

### Câu 7: Trong Microsoft Word 2010, cách nhanh nhất để chọn (bôi đen) từ con trỏ về đầu dòng là nhấn tổ hợp phím:
- [ ] A. Alt + F8
- [ ] B. Ctrl + End
- [ ] C. Shift + Home
- [ ] D. Alt + A

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* **Shift + Home** chọn từ con trỏ về đầu dòng hiện tại. (Shift + End là về cuối dòng).
</details>

---

### Câu 8: Trong Microsoft Word 2010, để chèn một Textbox trong văn bản, ta sử dụng:
- [ ] A. Insert \ Illustrations \ Text Box
- [ ] B. Insert \ Text \ Text Box
- [ ] C. Home \ Font \ Text Box
- [ ] D. Home \ Paragraph \ Text Box

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Lệnh Text Box nằm ở nhóm công cụ **Text** trong thẻ **Insert**.
</details>

---

### Câu 9: Trong Microsoft Word 2010, muốn xóa tất cả ký tự từ sau con trỏ văn bản đến khi gặp khoảng trắng đầu tiên (dấu cách), ta nhấn tổ hợp phím:
- [ ] A. Ctrl + D
- [ ] B. Alt + Delete
- [ ] C. Ctrl + Delete
- [ ] D. Alt + D

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* **Ctrl + Delete** xóa từ phía sau con trỏ tới hết từ tiếp theo.
</details>

---

### Câu 10: Trong một văn bản của Microsoft Word 2010, để chọn được nhiều hình không liền kề thì ta phải giữ thêm phím nào trong khi chọn:
- [ ] A. Shift
- [ ] B. Ctrl
- [ ] C. Alt
- [ ] D. Tab

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Giữ phím **Ctrl** khi click chuột để chọn nhiều đối tượng đồ họa không liền kề.
</details>

---

### Câu 11: Trong soạn thảo Microsoft Word 2010, để chuyển đổi chữ thường thành chữ in hoa hoặc ngược lại ta sử dụng tổ hợp phím:
- [ ] A. Ctrl + Shift + C
- [ ] B. Ctrl + Shift + A
- [ ] C. Ctrl + Shift + B
- [ ] D. Ctrl + Shift + D

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* **Ctrl + Shift + A** dùng để bật/tắt chế độ chữ in hoa toàn bộ (All Caps).
</details>

---

### Câu 12: Cổng COM là:
- [ ] A. Cổng nối tiếp
- [ ] B. Cổng song song
- [ ] C. Cổng vạn năng
- [ ] D. Cổng mạng

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* COM (Communication port) là cổng giao tiếp nối tiếp (Serial Port).
</details>

---

### Câu 13: Theo thứ tự đơn vị dung lượng tăng dần nào sau đây là đúng?
- [ ] A. Byte - Bit - KB - MB
- [ ] B. Bit - Byte - MB - KB
- [ ] C. Bit - Byte - KB - MB
- [ ] D. KB - Byte - Bit - MB

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* Thứ tự dung lượng chuẩn: 1 Byte = 8 Bit < 1 KB (1024 Byte) < 1 MB (1024 KB).
</details>

---

### Câu 14: Đơn vị đo tốc độ CPU là?
- [ ] A. Megabit (Mbps)
- [ ] B. Kylobyte (KBps)
- [ ] C. Kylobit (Kbps)
- [ ] D. Gigaherts (GHz)

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* Tần số xung nhịp đồng hồ của CPU được đo bằng Hertz, phổ biến là Gigahertz (GHz).
</details>

---

### Câu 15: Khi đang làm việc với Microsoft Excel 2010, có thể di chuyển từ sheet này sang sheet khác bằng cách sử dụng các phím hoặc các tổ hợp phím:
- [ ] A. Page Up; Page Down
- [ ] B. Ctrl + Page Up; Ctrl + Page Down
- [ ] C. Shift + Page Up; Shift + Page Down
- [ ] D. Alt + Page Up; Alt + Page Down

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* **Ctrl + Page Up** di chuyển sang sheet liền trước, **Ctrl + Page Down** chuyển sang sheet liền sau.
</details>

---

### Câu 16: Trong Microsoft Excel 2010, giả sử ô A1, A2, A3, có chứa lần lượt các số: 234, "235", 236, tại ô A4 ta điền công thức =SUM(A1:A3) thì kết quả là:
- [ ] A. 710
- [ ] B. 705
- [ ] C. 469
- [ ] D. 470

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* Khi truyền một mảng/vùng tham chiếu vào SUM, Excel sẽ tự động bỏ qua các giá trị dạng văn bản (chuỗi `"235"`). Do đó kết quả là: 234 + 236 = 470.
</details>

---

### Câu 17: Giá trị trả về của hàm =IF(10<2, "False", "True") trong Microsoft Excel 2010 là:
- [ ] A. True
- [ ] B. False
- [ ] C. 2024
- [ ] D. Sai

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Biểu thức điều kiện `10 < 2` nhận giá trị FALSE, vì vậy hàm trả về giá trị ở đối số thứ ba là `"True"`.
</details>

---

### Câu 18: Trong Microsoft Excel 2010, cột C xuất hiện ngay sau cột A là do:
- [ ] A. Cột B trong Excel đã bị xoá.
- [ ] B. Trong Excel không có cột B.
- [ ] C. Cột B bị ẩn (Hide).
- [ ] D. Cột B bị đổi thành tên khác.

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* Tiêu đề cột trong Excel cố định theo thứ tự chữ cái A, B, C... Cột B không biến mất hoàn toàn mà chỉ đang ở trạng thái ẩn (Hide).
</details>

---

### Câu 19: Trong Microsoft Excel 2010, hãy xác định địa chỉ nào là địa chỉ tuyệt đối?
- [ ] A. B$1:D$10
- [ ] B. $B1:$D10
- [ ] C. B$1$:D$10$
- [ ] D. $B$1:$D$10

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* Địa chỉ tuyệt đối có ký hiệu `$` đứng trước cả tên cột và chỉ số dòng (`$B$1:$D$10`).
</details>

---

### Câu 20: Trong Microsoft Excel, để tìm kiếm (Find) dữ liệu, ta dùng tổ hợp phím:
- [ ] A. Ctrl + H
- [ ] B. Ctrl + F
- [ ] C. Ctrl + B
- [ ] D. Ctrl + P

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* **Ctrl + F** mở hộp thoại Find (Tìm kiếm). Ctrl + H mở Find & Replace (Thay thế).
</details>

---

### Câu 21: Trong Microsoft Excel 2010, tổ hợp phím nào được sử dụng để tự động chèn hàm SUM vào ô hiện tại?
- [ ] A. Ctrl + =
- [ ] B. Alt + =
- [ ] C. Tab + =
- [ ] D. Shift + =

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Phím tắt **Alt + =** là phím tắt của tính năng AutoSum.
</details>

---

### Câu 22: Hàm nào có tác dụng trả về ngày hiện hành của hệ thống (không kèm giờ):
- [ ] A. =NOW()
- [ ] B. =DAY(NOW())
- [ ] C. =TODAY()
- [ ] D. =TODAY(NOW())

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* `=TODAY()` trả về ngày/tháng/năm hiện tại không kèm giờ. `=NOW()` trả về cả ngày và giờ.
</details>

---

### Câu 23: Địa chỉ của một khối dữ liệu trong Microsoft Excel 2010 được xác định bởi địa chỉ như sau:
- [ ] A. <Địa chỉ ô đầu tiên góc trên phải>:<Địa chỉ ô cuối cùng góc dưới trái>
- [ ] B. <Địa chỉ ô đầu tiên góc trên trái>:<Địa chỉ ô cuối cùng góc dưới phải>
- [ ] C. <Địa chỉ ô đầu tiên góc trên trái>:<Địa chỉ ô cuối cùng góc dưới trái>
- [ ] D. <Địa chỉ ô đầu tiên góc trên phải>:<Địa chỉ ô cuối cùng góc dưới phải>

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Cú pháp xác định vùng chọn trong Excel là từ ô góc trên bên trái đến ô góc dưới bên phải.
</details>

---

### Câu 24: Các phép so sánh hay các phép toán Logic trong Excel bao giờ cũng cho ra kết quả là:
- [ ] A. True hoặc False
- [ ] B. True
- [ ] C. True và False
- [ ] D. False

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Biểu thức logic chỉ trả về một trong hai giá trị Boolean: **TRUE** hoặc **FALSE**.
</details>

---

### Câu 25: Hãy cho biết, đâu là địa chỉ Gmail hợp lệ?
- [ ] A. DaihocTanTrao@gmail.com.vn
- [ ] B. DaihocTanTrao@gmail.vn.com
- [ ] C. DaihocTanTrao.gmail@com.vn
- [ ] D. DaihocTanTrao@com.vn.gmail

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Trong 4 lựa chọn, câu A có cú pháp cấu trúc tên miền hộp thư hợp lệ.
</details>