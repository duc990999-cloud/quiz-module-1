# Phần 3: Câu 51 – Câu 75

### Câu 51: Trong Microsoft Excel 2010, toán tử Logic nào có tác dụng trả về TRUE khi cả hai điều kiện đều đúng?
- [ ] A. Or
- [ ] B. NOT
- [ ] C. AND
- [ ] D. XOR

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* Hàm `AND` trả về TRUE khi và chỉ khi tất cả các biểu thức logic bên trong đều đúng.
</details>

---

### Câu 52: Trong Microsoft PowerPoint 2010, cách làm nào sau đây không phải để trình chiếu bài trình diễn:
- [ ] A. Home \ New Slide.
- [ ] B. Slide Show \ From Beginning.
- [ ] C. Nhấn tổ hợp phím Shift + F5.
- [ ] D. Nhấn phím F5.

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* **Home \ New Slide** dùng để tạo slide mới, không phải phát trình chiếu.
</details>

---

### Câu 53: Trong Microsoft PowerPoint 2010, để đưa thêm nút điều khiển (Action Buttons) vào slide hiện hành, người thiết kế có thể chọn:
- [ ] A. Insert \ Illustrations \ Shapes \ Action Buttons.
- [ ] B. AutoShapes \ Action Buttons.
- [ ] C. Slide Show \ Action Buttons.
- [ ] D. Design \ Action Buttons.

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Nút Action Buttons nằm trong danh sách hình khối Shapes tại thẻ Insert.
</details>

---

### Câu 54: Phần mở rộng của Microsoft PowerPoint 2010 là gì?
- [ ] A. docx
- [ ] B. xlsx
- [ ] C. html
- [ ] D. pptx

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* Tệp trình chiếu PowerPoint 2010 có phần mở rộng mặc định là `.pptx`.
</details>

---

### Câu 55: Trong các địa chỉ sau, địa chỉ nào thuộc dịch vụ Gmail?
- [ ] A. DaihocTanTrao@gmail.com
- [ ] B. DaihocTanTrao@outlook.com
- [ ] C. DaihocTanTrao.gmail@company.vn
- [ ] D. DaihocTanTrao@com.vn.gmail

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Địa chỉ thư điện tử của dịch vụ Gmail có đuôi miền chuẩn là `@gmail.com`.
</details>

---

### Câu 56: Trong Internet Explorer, phím tắt để đóng một Tab hiện tại là:
- [ ] A. Ctrl + N
- [ ] B. Ctrl + W
- [ ] C. Shift + T
- [ ] D. Alt + F4

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* **Ctrl + W** dùng để đóng tab đang xem trên các trình duyệt web.
</details>

---

### Câu 57: 2 GB bằng?
- [ ] A. 1000 MB
- [ ] B. 1500 MB
- [ ] C. 2048 MB
- [ ] D. 4096 MB

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* Theo hệ nhị phân, 1 GB = 1024 MB nên 2 GB = 2 * 1024 = 2048 MB.
</details>

---

### Câu 58: Đơn vị đo tốc độ truyền dữ liệu mạng thường dùng là:
- [ ] A. Gigahertz (GHz)
- [ ] B. Kylobyte (KB)
- [ ] C. Megabit/giây (Mbps)
- [ ] D. Gigabyte (GB)

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* Băng thông và tốc độ mạng đo bằng số bit truyền trong 1 giây (Megabit per second - Mbps).
</details>

---

### Câu 59: Cổng LPT là:
- [ ] A. Cổng nối tiếp
- [ ] B. Cổng song song
- [ ] C. Cổng vạn năng
- [ ] D. Cổng mạng

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* LPT (Line Print Terminal) là cổng giao tiếp song song (Parallel Port) chuyên dùng cắm máy in ngày trước.
</details>

---

### Câu 60: Bộ nhớ truy cập ngẫu nhiên RAM được viết tắt là:
- [ ] A. Read Access Memory
- [ ] B. Rewrite Access Memory
- [ ] C. Random Access Memory
- [ ] D. Secondary Memory

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* RAM viết tắt từ **Random Access Memory**.
</details>

---

### Câu 61: Thiết bị xuất gồm:
- [ ] A. Màn hình, máy in
- [ ] B. Scanner, webcam
- [ ] C. Chuột, bàn phím
- [ ] D. Loa, Micro

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Màn hình và máy in là hai thiết bị xuất cơ bản của hệ thống máy tính.
</details>

---

### Câu 62: Cổng LPT là:
- [ ] A. Cổng nối tiếp
- [ ] B. Cổng song song
- [ ] C. Cổng vạn năng
- [ ] D. Cổng mạng

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Cổng LPT là cổng song song (Parallel Port).
</details>

---

### Câu 63: Trong Microsoft Word 2010, khi đang soạn thảo một văn bản chưa lưu, nếu ta chọn tổ hợp phím Ctrl + S thì thao tác nào sau đây sẽ xảy ra (lần lưu đầu tiên):
- [ ] A. Mở hộp thoại "Save As" để đặt tên và chọn nơi lưu
- [ ] B. Đóng văn bản ngay lập tức
- [ ] C. In văn bản ra máy in
- [ ] D. Chuyển văn bản sang chế độ đọc (Read Mode)

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Khi file chưa từng lưu, lệnh lưu Ctrl + S sẽ kích hoạt hộp thoại Save As.
</details>

---

### Câu 64: Trong Microsoft Word 2010, khi ta thực hiện thao tác chọn Page Layout \ Page Setup \ Orientation \ Portrait có nghĩa là:
- [ ] A. Chọn hướng giấy ngang
- [ ] B. Chọn hướng giấy dọc
- [ ] C. Điều chỉnh lề cho trang giấy
- [ ] D. Thiết lập khổ giấy (A4, Letter, ...)

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* **Portrait** đại diện cho hướng giấy dọc.
</details>

---

### Câu 65: Trong hệ điều hành Windows, muốn đóng nhanh cửa sổ (ứng dụng) đang mở, cần sử dụng tổ hợp phím:
- [ ] A. Alt + Tab
- [ ] B. Alt + Shift
- [ ] C. Alt + Home
- [ ] D. Alt + F4

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* **Alt + F4** thoát hoặc đóng nhanh cửa sổ ứng dụng hiện hành.
</details>

---

### Câu 66: Trong Microsoft Word 2010, để xóa bỏ toàn bộ định dạng đoạn văn (paragraph formatting) của văn bản đang chọn, ta nhấn tổ hợp phím:
- [ ] A. Ctrl + Space
- [ ] B. Ctrl + Delete
- [ ] C. Ctrl + Enter
- [ ] D. Ctrl + Q

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* **Ctrl + Q** loại bỏ các định dạng đoạn (căn dòng, thụt lề...), còn Ctrl + Space loại bỏ định dạng ký tự.
</details>

---

### Câu 67: Trong Microsoft Word 2010, cách nhanh nhất để chọn (bôi đen) từ con trỏ về cuối dòng là nhấn tổ hợp phím:
- [ ] A. Alt + F8
- [ ] B. Ctrl + End
- [ ] C. Shift + End
- [ ] D. Alt + A

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: C**  
> *Giải thích:* **Shift + End** chọn văn bản từ vị trí con trỏ hiện hành tới cuối dòng.
</details>

---

### Câu 68: Trong Microsoft Word 2010, thao tác nhấp chuột 2 lần (double - click) vào một từ trong đoạn văn bản sẽ có tác dụng gì:
- [ ] A. Chọn đoạn văn bản
- [ ] B. Chọn toàn bộ văn bản
- [ ] C. Chọn một câu tại vị trí con trỏ
- [ ] D. Chọn một từ

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* Nhấp đúp chuột vào một từ sẽ bôi đen (chọn) chính xác từ đó. Nhấp 3 lần để chọn cả đoạn.
</details>

---

### Câu 69: Trong Microsoft Word 2010, muốn xóa tất cả ký tự từ trước con trỏ văn bản lùi về đến khi gặp khoảng trắng đầu tiên (dấu cách) ta nhấn tổ hợp phím:
- [ ] A. Ctrl + Backspace
- [ ] B. Alt + Delete
- [ ] C. Ctrl + Delete
- [ ] D. Alt + D

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* **Ctrl + Backspace** xóa từ trước con trỏ về bên trái đến khoảng trắng gần nhất.
</details>

---

### Câu 70: Trong một văn bản của Microsoft Word 2010, để chọn nhiều hình (hoặc đối tượng) liền kề nhau, ta cần giữ phím nào trong khi chọn?
- [ ] A. Shift
- [ ] B. Ctrl
- [ ] C. Alt
- [ ] D. Tab

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: A**  
> *Giải thích:* Phím **Shift** được dùng để chọn liên tiếp các đối tượng liền kề.
</details>

---

### Câu 71: Trong soạn thảo Microsoft Word 2010, muốn đánh số đầu đoạn văn bản (1, 2, 3, ...), ta chọn:
- [ ] A. Insert \ Symbol
- [ ] B. Home \ Paragraph \ Bullets
- [ ] C. Home \ Symbol
- [ ] D. Home \ Paragraph \ Numbering

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* **Numbering** trong nhóm Paragraph thẻ Home dùng để đánh số thứ tự đầu đoạn.
</details>

---

### Câu 72: Trong soạn thảo Microsoft Word 2010, để chuyển đổi chữ thường thành chữ in hoa hoặc ngược lại ta sử dụng tổ hợp phím:
- [ ] A. Ctrl + Shift + C
- [ ] B. Shift + A
- [ ] C. Ctrl + Shift + B
- [ ] D. Shift + F3

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: D**  
> *Giải thích:* **Shift + F3** thực hiện chuyển đổi kiểu chữ hoa/thường (Change Case).
</details>

---

### Câu 73: Trong Microsoft Excel 2010, tại ô A2 có giá trị là chuỗi TinHoc; Tại ô C2 gõ vào công thức =UPPER(A2) thì nhận được kết quả tại ô C2:
- [ ] A. #Value
- [ ] B. TINHOC
- [ ] C. TinHoc
- [ ] D. tinhoc

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Hàm `=UPPER()` chuyển đổi chuỗi thành toàn bộ chữ in hoa.
</details>

---

### Câu 74: Trong Microsoft Excel 2010, giả sử ô A1, A2, A3, có chứa lần lượt các số: 234, "235", 236, tại ô A4 nhập công thức =COUNT(A1:A3) thì kết quả là:
- [ ] A. 3
- [ ] B. 2
- [ ] C. 1
- [ ] D. 0

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* `COUNT()` chỉ đếm số lượng ô có kiểu dữ liệu số thực sự, ô A2 chứa văn bản `"235"` nên không được đếm (kết quả = 2).
</details>

---

### Câu 75: Giá trị trả về của hàm =IF(10>2, "False", "True") trong Microsoft Excel 2010 là:
- [ ] A. True
- [ ] B. False
- [ ] C. 2024
- [ ] D. Đúng

<details>
<summary><b>👉 Xem đáp án</b></summary>

> **Đáp án đúng: B**  
> *Giải thích:* Điều kiện `10 > 2` đúng nên lấy giá trị khi đúng là `"False"`.
</details>